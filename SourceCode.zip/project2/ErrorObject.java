public class ErrorObject {
  public int Column;
  public String Message;

  public ErrorObject(int column, String message) {
    Column = column;
    Message = message;
  }
}
