public enum DataType {
  NONE, INT, REAL, ID, KEYWORD, OP
}