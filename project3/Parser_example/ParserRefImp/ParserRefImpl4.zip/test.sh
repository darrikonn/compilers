./build.sh
java MyMain test.decaf
