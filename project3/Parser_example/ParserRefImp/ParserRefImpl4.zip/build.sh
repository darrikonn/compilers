rm *.class
jflex-1.6.0/bin/jflex lexical.flex
javac *.java