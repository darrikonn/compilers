./build.sh
java MyMain test_with_errors.decaf
