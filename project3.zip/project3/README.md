# Compiler Project III
Tac interpreter, coded by `darrikonn`.

# Run
Run the program with:
> java -jar TacGenerator.jar <mydecaf>.decaf

You can also run all the tests in *testcode* with the runtests script. It places the output into the folder *testoutput*.
> runtests.sh
