#!/bin/bash
./renew.sh

java -jar TacGenerator.jar testcode/code_and.decaf | sed 1,2d > testoutput/and.tac
java -jar TacGenerator.jar testcode/code_fact.decaf | sed 1,2d > testoutput/fact.tac
java -jar TacGenerator.jar testcode/code_for.decaf | sed 1,2d > testoutput/for.tac
java -jar TacGenerator.jar testcode/code_func.decaf | sed 1,2d > testoutput/func.tac
java -jar TacGenerator.jar testcode/code_if.decaf | sed 1,2d > testoutput/if.tac
java -jar TacGenerator.jar testcode/Example1.decaf | sed 1,2d > testoutput/ex1.tac
java -jar TacGenerator.jar testcode/Example2.decaf | sed 1,2d > testoutput/ex2.tac
java -jar TacGenerator.jar testcode/Example3.decaf | sed 1,2d > testoutput/ex3.tac
java -jar TacGenerator.jar testcode/Example_with_errors.decaf > testoutput/errors.txt
java -jar TacGenerator.jar testcode/Example_without_errors.decaf | sed 1,2d > testoutput/noerrors.tac

java -jar TAC_Interpreter/JTacInt.jar testoutput/and.tac
java -jar TAC_Interpreter/JTacInt.jar testoutput/fact.tac
java -jar TAC_Interpreter/JTacInt.jar testoutput/for.tac
java -jar TAC_Interpreter/JTacInt.jar testoutput/func.tac
java -jar TAC_Interpreter/JTacInt.jar testoutput/if.tac
java -jar TAC_Interpreter/JTacInt.jar testoutput/ex1.tac
java -jar TAC_Interpreter/JTacInt.jar testoutput/ex2.tac
java -jar TAC_Interpreter/JTacInt.jar testoutput/ex3.tac
java -jar TAC_Interpreter/JTacInt.jar testoutput/noerrors.tac
